Redapp for Linux

1. Extract this ZIP to a folder.
2. Open a terminal in that folder.
3. Run: sh run-redapp-linux.sh
   (or make it executable first: chmod +x run-redapp-linux.sh && ./run-redapp-linux.sh)

Redapp opens in its own window using Chrome, Chromium, Edge or Brave.
If none is found, it opens in your default browser.

Note: this is the Redapp web app packaged for desktop. It is not a native installer.
You need an internet connection to chat.
