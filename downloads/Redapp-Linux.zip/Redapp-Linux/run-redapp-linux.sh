#!/bin/sh
# Opens Redapp in its own window (Chrome, Chromium, Edge or Brave), or in your default browser.
cd "$(dirname "$0")" || exit 1
URL="file://$PWD/index.html"
for b in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge microsoft-edge-stable brave-browser; do
  if command -v "$b" >/dev/null 2>&1; then
    exec "$b" --app="$URL"
  fi
done
if command -v xdg-open >/dev/null 2>&1; then
  exec xdg-open "$URL"
elif command -v gio >/dev/null 2>&1; then
  exec gio open "$URL"
else
  echo "Open this file in your browser: $PWD/index.html"
fi
