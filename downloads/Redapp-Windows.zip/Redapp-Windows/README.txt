Redapp for Windows

1. Extract this ZIP to a folder.
2. Double-click Run-Redapp-Windows.bat.

Redapp opens in its own window using Microsoft Edge or Google Chrome.
If neither is found, it opens in your default browser.

Note: this is the Redapp web app packaged for desktop. It is not a native installer.
You need an internet connection to chat.
