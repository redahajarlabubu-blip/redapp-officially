@echo off
cd /d "%~dp0"
set "APP=%~dp0index.html"
set "URL=file:///%APP:\=/%"
for %%B in ("%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe") do (
  if exist %%B (
    start "" %%B --app="%URL%"
    exit /b
  )
)
start "" "%APP%"
